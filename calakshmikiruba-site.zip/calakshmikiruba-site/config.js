// Paste your Apps Script web app link between the quotes below.
// It must start with https://script.google.com/ and end with /exec
window.SITE_API = "PASTE_YOUR_EXEC_LINK_HERE";
